from django.http import HttpResponse
from django.shortcuts import render


def home(request):
    return render(request,"home.html")
def login(request):
    return render(request,"login.html")
def about(request):
    return HttpResponse("I am in About Page")
def contact(request):
    return HttpResponse("I am in Contact us Page")