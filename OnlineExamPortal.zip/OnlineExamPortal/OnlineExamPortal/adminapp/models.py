from django.db import models

# Create your models here.
class Admin(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100,blank=False,unique=True)
    password = models.CharField(max_length=100,blank=False)

    class Meta:
        db_table = "admin_table"

    def __str__(self):
        return self.username

class Quiz1(models.Model):
    id = models.AutoField(primary_key=True)
    question = models.CharField(max_length=250,blank=False,unique=True)
    option1 = models.CharField(max_length=50,blank=False)
    option2 = models.CharField(max_length=50, blank=False)
    option3 = models.CharField(max_length=50, blank=False)
    option4 = models.CharField(max_length=50, blank=False)
    answer  = models.CharField(max_length=50,blank=False)
class Quiz2(models.Model):
    id = models.AutoField(primary_key=True)
    question = models.CharField(max_length=250,blank=False,unique=True)
    option1 = models.CharField(max_length=50,blank=False)
    option2 = models.CharField(max_length=50, blank=False)
    option3 = models.CharField(max_length=50, blank=False)
    option4 = models.CharField(max_length=50, blank=False)
    answer  = models.CharField(max_length=50,blank=False)

class Quiz3(models.Model):
    id = models.AutoField(primary_key=True)
    question = models.CharField(max_length=250,blank=False,unique=True)
    option1 = models.CharField(max_length=50,blank=False)
    option2 = models.CharField(max_length=50, blank=False)
    option3 = models.CharField(max_length=50, blank=False)
    option4 = models.CharField(max_length=50, blank=False)
    answer  = models.CharField(max_length=50,blank=False)

class Quiz4(models.Model):
    id = models.AutoField(primary_key=True)
    question = models.CharField(max_length=250,blank=False,unique=True)
    option1 = models.CharField(max_length=50,blank=False)
    option2 = models.CharField(max_length=50, blank=False)
    option3 = models.CharField(max_length=50, blank=False)
    option4 = models.CharField(max_length=50, blank=False)
    answer  = models.CharField(max_length=50,blank=False)

class StudentQuiz1(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30,blank=False,)
    answer1 = models.CharField(max_length=50,blank=False)
    answer2 = models.CharField(max_length=50, blank=False)
    answer3 = models.CharField(max_length=50, blank=False)
    answer4 = models.CharField(max_length=50, blank=False)
    answer5 = models.CharField(max_length=50, blank=False)

class Score(models.Model):
    id = models.AutoField(primary_key=True)
    student_id = models.BigIntegerField(blank=True,unique=True)
    quiz1 = models.IntegerField(blank=True,unique=True)
    quiz2 = models.IntegerField(blank=True,unique=True)
    quiz3 = models.IntegerField(blank=True,unique=True)
    quiz4 = models.IntegerField(blank=True,unique=True)