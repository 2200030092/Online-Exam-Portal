from django.contrib import admin
from .models import Admin, Quiz1, Quiz2, Quiz3, Quiz4, Score

# Register your models here.
admin.site.register(Admin)
admin.site.register(Quiz1)
admin.site.register(Quiz2)
admin.site.register(Quiz3)
admin.site.register(Quiz4)
admin.site.register(Score)