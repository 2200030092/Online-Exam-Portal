from django.contrib import admin
from django.urls import path, include

from . import views

urlpatterns = [
    path('adminhome',views.adminhome,name='adminhome'),
    path('checkadminlogin',views.checkadminlogin,name='checkadminlogin'),
    path("adminlogout",views.adminlogout,name="adminlogout"),
    path("conductquiz",views.conductquiz,name="conductquiz"),
    path("insertquiz",views.insertquiz,name="insertquiz"),
    path("conductquizhome",views.conductquizhome,name="conductquizhome"),
    path("insertquiz2",views.insertquiz2,name="insertquiz2"),
    path("conductquiz2",views.conductquiz2,name="conductquiz2"),
    path("insertquiz3",views.insertquiz3,name="insertquiz3"),
    path("conductquiz3",views.conductquiz3,name="conductquiz3"),
    path("insertquiz4",views.insertquiz4,name="insertquiz4"),
    path("conductquiz4",views.conductquiz4,name="conductquiz4"),
    path("attendquiz",views.attendquiz,name="attendquiz"),
    path("attendquiz1",views.attendquiz1,name="attendquiz1"),
    path("attendquiz2",views.attendquiz2,name="attendquiz2"),
    path("attendquiz3",views.attendquiz3,name="attendquiz3"),
    path("attendquiz4",views.attendquiz4,name="attendquiz4"),
    path("checkquiz1",views.checkquiz1,name="checkquiz1"),
    path("checkquiz2",views.checkquiz2,name="checkquiz2"),
    path("checkquiz3",views.checkquiz3,name="checkquiz3"),
    path("checkquiz4",views.checkquiz4,name="checkquiz4"),
    path("loginhome",views.loginhome,name="loginhome"),
    path("studentlogin",views.studentlogin,name="studentlogin"),
    path("teacherlogin",views.teacherlogin,name="teacherlogin"),
    path("teacherhome",views.teacherhome,name="teacherhome"),
    path('checkteacherlogin', views.checkteacherlogin, name='checkteacherlogin'),
    path('checkstudentlogin', views.checkstudentlogin, name='checkstudentlogin'),
    path("studenthome", views.studenthome, name="studenthome"),
]