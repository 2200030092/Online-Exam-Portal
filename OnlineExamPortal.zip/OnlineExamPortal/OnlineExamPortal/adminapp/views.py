from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render, redirect

from .models import Admin, Quiz1, Quiz2, Quiz3, Quiz4


# Create your views here.
def adminhome(request):
    return render(request,"adminhome.html")
def student(request):
    return render(request,"student.html")
def faculty(request):
    return render(request,"faculty.html")
def adminlogout(request):
    return render(request,"home.html")
def loginhome(request):
    return render(request,"loginhome.html")
def studentlogin(request):
    return render(request,"studentlogin.html")
def teacherlogin(request):
    return render(request,"teacherlogin.html")
def checkadminlogin(request):
    adminuname = request.POST["uname"]
    adminpwd = request.POST["pwd"]

    flag=Admin.objects.filter(Q(username=adminuname)&Q(password=adminpwd))
    print(flag)

    if flag:
        print("Login Success")
        request.session["auname"]= adminuname
        return render(request,"adminhome.html",{"adminuname": adminuname})
    else:
        msg="Login Failed"
        return render(request,"login.html",{"message":msg})
        #return HttpResponse("login failed")
def teacherhome(request):
    return render(request,"teacherhome.html")

def studenthome(request):
    return render(request,"studenthome.html")
def conductquiz(request):
    return render(request,"conductquiz.html")

def conductquiz2(request):
    return render(request,"conductquiz2.html")

def conductquiz3(request):
    return render(request,"conductquiz3.html")

def conductquiz4(request):
    return render(request,"conductquiz4.html")

def conductquizhome(request):
    return render(request,"conductquizhome.html")

def insertquiz(request):
    ques=request.POST["ques"]
    opt1=request.POST["opt1"]
    opt2=request.POST["opt2"]
    opt3=request.POST["opt3"]
    opt4=request.POST["opt4"]
    ans =request.POST["ans"]

    quiz1=Quiz1(question=ques,option1=opt1,option2=opt2,option3=opt3,option4=opt4,answer=ans)

    Quiz1.save(quiz1)

    message="Quiz Added Successfully"

    return  render(request,"conductquiz.html",{"msg":message})

def insertquiz2(request):
    ques=request.POST["ques"]
    opt1=request.POST["opt1"]
    opt2=request.POST["opt2"]
    opt3=request.POST["opt3"]
    opt4=request.POST["opt4"]
    ans =request.POST["ans"]

    quiz2=Quiz2(question=ques,option1=opt1,option2=opt2,option3=opt3,option4=opt4,answer=ans)

    Quiz2.save(quiz2)

    message="Quiz Added Successfully"

    return  render(request,"conductquiz.html",{"msg":message})

def insertquiz3(request):
    ques=request.POST["ques"]
    opt1=request.POST["opt1"]
    opt2=request.POST["opt2"]
    opt3=request.POST["opt3"]
    opt4=request.POST["opt4"]
    ans =request.POST["ans"]

    quiz3=Quiz3(question=ques,option1=opt1,option2=opt2,option3=opt3,option4=opt4,answer=ans)

    Quiz3.save(quiz3)

    message="Quiz Added Successfully"

    return  render(request,"conductquiz.html",{"msg":message})

def insertquiz4(request):
    ques=request.POST["ques"]
    opt1=request.POST["opt1"]
    opt2=request.POST["opt2"]
    opt3=request.POST["opt3"]
    opt4=request.POST["opt4"]
    ans =request.POST["ans"]

    quiz4=Quiz4(question=ques,option1=opt1,option2=opt2,option3=opt3,option4=opt4,answer=ans)

    Quiz4.save(quiz4)

    message="Quiz Added Successfully"

    return  render(request,"conductquiz.html",{"msg":message})

def attendquiz(request):
    return render(request,"attendquiz.html")
def checkquiz1(request):
    return render(request, 'checkquiz1.html')

def checkquiz2(request):
    return render(request, 'checkquiz2.html')

def checkquiz3(request):
    return render(request, 'checkquiz3.html')

def checkquiz4(request):
    return render(request, 'checkquiz4.html')
def attendquiz1(request):
    quiz1 = Quiz1.objects.all()
    return render(request,"attendquiz1.html",{"Quiz1Data": quiz1})
def attendquiz2(request):
    quiz2 = Quiz2.objects.all()
    return render(request, "attendquiz2.html", {"Quiz2Data": quiz2})
def attendquiz3(request):
    quiz3 = Quiz3.objects.all()
    return render(request, "attendquiz3.html", {"Quiz3Data": quiz3})
def attendquiz4(request):
    quiz4 = Quiz4.objects.all()
    return render(request, "attendquiz4.html", {"Quiz4Data": quiz4})

def checkteacherlogin(request):
    adminuname = request.POST["uname"]
    adminpwd = request.POST["pwd"]

    flag=Admin.objects.filter(Q(username=adminuname)&Q(password=adminpwd))
    print(flag)

    if flag:
        print("Login Success")
        request.session["auname"]= adminuname
        return render(request,"teacherhome.html",{"adminuname": adminuname})
    else:
        msg="Login Failed"
        return render(request,"teacherlogin.html",{"message":msg})
        #return HttpResponse("login failed")

def checkstudentlogin(request):
    adminuname = request.POST["uname"]
    adminpwd = request.POST["pwd"]

    flag=Admin.objects.filter(Q(username=adminuname)&Q(password=adminpwd))
    print(flag)

    if flag:
        print("Login Success")
        request.session["auname"]= adminuname
        return render(request,"studenthome.html",{"adminuname": adminuname})
    else:
        msg="Login Failed"
        return render(request,"studentlogin.html",{"message":msg})
        #return HttpResponse("login failed")
