from django.apps import AppConfig


class StudentappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'studentapp'
